//Your WiFi credentials
const char ssid[] = "TRex";
const char password[] =  "hasBigTeeth";

//Your AssistNow token
const char myAssistNowToken[] = "58XXXXXXXXXXXXXXXXXXYQ";
